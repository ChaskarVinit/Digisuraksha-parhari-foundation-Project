import io
import gc
from micropython import const
import socketpool
import wifi


class BadRequestError(Exception):
    """Raised when the client sends an unexpected empty line"""
    pass


# Constants
_BUFFER_SIZE = 32
NO_SOCK_AVAIL = const(255)
buffer = bytearray(_BUFFER_SIZE)


def readline(socketin):
    """
    Implement readline() for native wifi using recv_into.
    Reads one line (terminated by \r\n) from the socket.
    """
    data_string = b""
    try:
        while True:
            num = socketin.recv_into(buffer, 1)
            data_string += buffer[:num]
            if num == 0 or data_string.endswith(b"\r\n"):
                return data_string.rstrip(b"\r\n")
    except OSError as ex:
        if ex.errno == 11:  # [Errno 11] EAGAIN, no data available yet
            return None
        raise


def read(socketin, length=-1):
    """
    Reads a specific number of bytes from the socket or until EOF.
    """
    total = 0
    data_string = b""
    try:
        if length > 0:
            while total < length:
                to_read = min(_BUFFER_SIZE, length - total)
                num = socketin.recv_into(buffer, to_read)
                if num == 0:
                    break
                data_string += buffer[:num]
                total += num
        else:
            while True:
                num = socketin.recv_into(buffer, 1)
                if num == 0:
                    break
                data_string += buffer[:num]
        return data_string
    except OSError as ex:
        if ex.errno == 11:  # [Errno 11] EAGAIN, no data available yet
            return data_string
        raise


def parse_headers(sock):
    """
    Parses the HTTP headers from the socket.
    Returns a dictionary of headers.
    """
    headers = {}
    while True:
        line = readline(sock)
        if not line:
            break
        title, content = line.split(b': ', 1)
        headers[title.lower().decode()] = content.decode()
    return headers


class WSGIServer:
    """
    A simple WSGI server for handling HTTP requests on ESP32 over SPI.
    """

    def __init__(self, port=80, debug=False, application=None):
        self.application = application
        self.port = port
        self.debug = debug

        # Server and client sockets
        self._server_sock = None
        self._client_sock = None

        # Response variables
        self._response_status = None
        self._response_headers = []

    def start(self):
        """
        Starts the server and listens for incoming connections.
        """
        try:
            pool = socketpool.SocketPool(wifi.radio)
            self._server_sock = pool.socket(pool.AF_INET, pool.SOCK_STREAM)
            self._server_sock.bind((str(wifi.radio.ipv4_address_ap), self.port))
            self._server_sock.listen(1)
            print(f"Server started at {self.pretty_ip()}")
        except Exception as e:
            print(f"Error starting server: {e}")

    def pretty_ip(self):
        return f"http://{wifi.radio.ipv4_address_ap}:{self.port}"

    def update_poll(self):
        """
        Polls for incoming client requests and handles them.
        """
        self._client_sock = self._accept_client()
        if self._client_sock:
            try:
                environ = self._get_environ(self._client_sock)
                result = self.application(environ, self._start_response)
                self._send_response(result)
            except BadRequestError:
                self._start_response("400 Bad Request", [])
                self._send_response([])
            finally:
                self._cleanup()

    def _accept_client(self):
        """
        Checks for a new client connection.
        """
        try:
            self._server_sock.setblocking(False)
            return self._server_sock.accept()[0]  # Accept client connection
        except OSError as ex:
            if ex.errno != 11:  # [Errno 11] EAGAIN means no client yet
                print(f"Error accepting client: {ex}")
        return None

    def _start_response(self, status, response_headers):
        """
        Sets the response status and headers.
        """
        self._response_status = status
        self._response_headers = [("Server", "esp32WSGIServer")] + response_headers

    def _send_response(self, result):
        """
        Sends the HTTP response to the client.
        """
        try:
            response = f"HTTP/1.1 {self._response_status}\r\n"
            for header in self._response_headers:
                response += f"{header[0]}: {header[1]}\r\n"
            response += "\r\n"
            self._client_sock.send(response.encode())

            for data in result:
                if isinstance(data, str):
                    data = data.encode()
                self._client_sock.send(data)
        except OSError as ex:
            if ex.errno != 104:  # [Errno 104] ECONNRESET means client reset connection
                print(f"Error sending response: {ex}")

    def _get_environ(self, client):
        """
        Creates the WSGI environ dictionary with metadata about the incoming request.
        """
        env = {}
        request_line = readline(client).decode()
        try:
            method, path, version = request_line.split(None, 2)
        except ValueError:
            raise BadRequestError("Invalid request line")

        env["REQUEST_METHOD"] = method
        env["PATH_INFO"] = path.split('?')[0]
        env["QUERY_STRING"] = path.split('?')[1] if '?' in path else ""
        env["SERVER_PROTOCOL"] = version
        env["SERVER_NAME"] = str(wifi.radio.ipv4_address_ap)
        env["SERVER_PORT"] = self.port

        headers = parse_headers(client)
        for name, value in headers.items():
            env[f"HTTP_{name.replace('-', '_').upper()}"] = value

        if "content-length" in headers:
            body = read(client, int(headers["content-length"]))
            env["wsgi.input"] = io.StringIO(body.decode())
        else:
            env["wsgi.input"] = io.StringIO("")

        return env

    def _cleanup(self):
        """
        Closes the client socket and performs memory cleanup.
        """
        if self._client_sock:
            self._client_sock.close()
            self._client_sock = None
        gc.collect()
